#Description
Arthur Scherbius: I will protect German information using my machine 
Alan Turing : No , I can break your machine :)
Arthur Scherbius: Well, I will count upto 3, Get my message from ``LDOFKDCGIAGCCOTKMGSTSV``.
note: 1. seperate words using space 
      2. flag : inctfj{message}
