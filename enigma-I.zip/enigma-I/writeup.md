#writeup
Count is upto 3,where you are given with ROTORS TO MOUNT, use online solver.
